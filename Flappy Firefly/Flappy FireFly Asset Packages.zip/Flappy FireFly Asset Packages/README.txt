Each Folder contains the full Asset File containing the state of all files and scripts at the end of the video it is labeled for.
